<?php 

$nama = $_POST["nama"];
$harga = $_POST["harga"];
$jumlah = $_POST["jumlah"];
$diskon = $_POST["diskon"];
$uang = $_POST["uang"];

$subtotal = $harga * $jumlah;
$jumlah_diskon = $subtotal * ($diskon/100);
$total = $subtotal - $jumlah_diskon; 
$kembalian = $uang - $total;

echo "$nama <br>
Harga : $harga <br>
Jumlah : $jumlah <br>
Sub Total : $subtotal <br>
Diskon : $jumlah_diskon <br>
Total : $total <br>
Kembalian : $kembalian "

?>