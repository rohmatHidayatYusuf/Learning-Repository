<?php 
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kasir</title>
</head>
<body>
    <form method="POST" action="hitung.php">
        <label for="">Masukan Nama barang</label><br>
        <input type="text" name="nama" placeholder="contoh : Beras" require><br><br>

        <label for="">Masukan Harga</label><br>
        <input type="number" name="harga" placeholder="contoh : 17000" require><br><br>

        <label for="">Masukan Jumlah barang</label><br>
        <input type="number" name="jumlah" placeholder="contoh : 2" require><br><br>

        <label for="">Masukan diskon</label><br>
        <input type="number" name="diskon" placeholder="contoh : 50" require><br><br>
        
        <label for="">Masukan uang</label><br>
        <input type="number" name="uang" placeholder="contoh : 20000" require><br><br>

        <button type="submit">Tambah</button>
    </form>

</body>
</html>