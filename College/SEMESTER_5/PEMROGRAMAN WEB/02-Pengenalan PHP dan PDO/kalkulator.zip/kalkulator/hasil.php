<?php 
$angka1 = $_POST['angka1'];
$angka2 = $_POST['angka2'];
$operator = $_POST['operator'];

if ($operator == "+") {
    $hasil = $angka1 + $angka2;
}elseif ($operator == "-") {
    $hasil = $angka1 - $angka2;
}elseif ($operator == "*") {
    $hasil = $angka1 * $angka2;
}else {
    $hasil = $angka1 / $angka2;
}

echo "Hasil dari $angka1 $operator $angka2 adalah $hasil <br><br>";
echo "<a href='index.php'>Kembali</a>";

?>