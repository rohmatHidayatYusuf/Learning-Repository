<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>kalkulator</title>
</head>
<body>
    <form method="POST" action="hasil.php">
        <input type="number" name="angka1" placeholder="Masukkan Angka" required><br><br>
        <input type="number" name="angka2" placeholder="Masukkan Angka" required><br><br>
        <select name="operator">
            <option value="">Silakan Pilih Operator</option>
            <option value="+">+</option>
            <option value="-">-</option>
            <option value="*">*</option>
            <option value="/">/</option>
        </select>

        <button type="submit"> = </button>
    </form>
</body>
</html>